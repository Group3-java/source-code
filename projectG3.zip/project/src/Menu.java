import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Component;

public class Menu extends JFrame implements ActionListener{

    JTable jTable;
    JButton barGraph = new JButton("Bar Graph");
    JButton histogram = new JButton("Histogram");
    JButton lineGraph = new JButton("Line Graph");
    JButton pieChart = new JButton("Pie Chart");
    JButton donutGraph = new JButton("Doughnut Graph");
    JButton scatter = new JButton("Scatter");
    JMenuItem save = new JMenuItem("Save");
    JMenu open = new JMenu("Open");
    JMenuItem exit = new JMenuItem("Exit");

    //changes
    JMenuItem[] files = new JMenuItem[5];

    JButton okay = new JButton("Okay");
    JButton cancel = new JButton("Cancel");
    JFrame labelPopup = new JFrame();
    JLabel prompt = new JLabel("Enter Graph Name:");
    JTextField graphName = new JTextField();
    JLabel graphLabel = new JLabel();

    //CHANGE
    String selectedCells[][];
    String selectedCellsPrint[][]= new String[26][60];
    String [][] data;

    public Menu(){

    //JFRAME SETTINGS
        JFrame f = new JFrame("Project 3 : Data Visualization Software");
        Main.connect();

        f.setSize(1000,400);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        f.getContentPane().setBackground(Color.getHSBColor(0,0f,0.9f));






    //DROPDOWN MENUBAR STUFF
        JMenuBar jMenuBar = new JMenuBar();
        JMenu file = new JMenu("File");//change
        JMenu home = new JMenu("Home");
        JMenu insert = new JMenu("Insert");
        JMenu pageLayout = new JMenu("Page Layout");
        JMenu formulas = new JMenu("Formulas");
        JMenu dataMenu = new JMenu("Data");
        JMenu review = new JMenu("Review");
        JMenu view = new JMenu("View");
        JMenu developer = new JMenu("Developer");
        JMenu help = new JMenu("Help");



        save.addActionListener(this);
        open.addActionListener(this);
        exit.addActionListener(this);

        file.add(save);
        file.add(open);
        file.add(exit);

        jMenuBar.add(file);
        jMenuBar.add(home);
        jMenuBar.add(insert);
        jMenuBar.add(pageLayout);
        jMenuBar.add(formulas);
        jMenuBar.add(dataMenu);
        jMenuBar.add(review);
        jMenuBar.add(view);
        jMenuBar.add(developer);
        jMenuBar.add(help);

        //main change
        file.addMenuListener(new MenuListener() {
            @Override
            public void menuSelected(MenuEvent e) {
                int i=0;
                //jTable.setValueAt("9",0,0);
                String[] fileNames = Main.getFileNames();
                open.removeAll();

                while (fileNames[i] != null){
                    files[i] = new JMenuItem(fileNames[i]);
                    //System.out.println(fileNames[i]);
                    open.add(files[i]);

                    //files[i].addActionListener(Menu.this);
                    int index = i;
                    files[i].addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            loadFile(files[index].getText());
                        }
                    });
                    i++;
                }
                if(fileNames[0]==null)open.add("No Saved File!!");
            }

            @Override
            public void menuDeselected(MenuEvent e) {

            }

            @Override
            public void menuCanceled(MenuEvent e) {

            }
        });

        jMenuBar.setBackground(Color.getHSBColor(30,0.01f,0.95f));
        f.setJMenuBar(jMenuBar);
        f.setLayout(new BoxLayout(f.getContentPane(),BoxLayout.PAGE_AXIS));



     //JPANELS
        JPanel plotGraph = new JPanel();
        plotGraph.setBackground(Color.getHSBColor(0,0f,0.9f));
        plotGraph.setMaximumSize(new Dimension(10000,300));

        JPanel spreadsheet = new JPanel();




        //plot graph panel buttons

                //Cell details panel contents

                JLabel jLabel = new JLabel("      ");

                JTextField jTextField = new JTextField();
                jTextField.setEditable(false);
                jTextField.setPreferredSize(new Dimension(60,30));
                jTextField.setHorizontalAlignment(SwingConstants.LEFT);

                FlowLayout flowLayout = new FlowLayout();
                flowLayout.setAlignment(FlowLayout.LEFT);
                flowLayout.setHgap(15);
                flowLayout.setVgap(10);

                plotGraph.setLayout(flowLayout);
                plotGraph.add(jTextField);
                plotGraph.add(jLabel);


                //barGraph

                BufferedImage imgbar = null;
                try {
                    imgbar = ImageIO.read(new File("hist.png"));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Image dimgbar = imgbar.getScaledInstance(30,30, Image.SCALE_SMOOTH);
                ImageIcon barIcon = new ImageIcon(dimgbar);

                
                barGraph.setIcon(barIcon);
                barGraph.setBackground(Color.white);

                plotGraph.add(barGraph);




                //histogram

                BufferedImage imghist = null;
                try {
                    imghist = ImageIO.read(new File("bar.png"));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Image dimghist = imghist.getScaledInstance(30,30, Image.SCALE_SMOOTH);
                ImageIcon histIcon = new ImageIcon(dimghist);

                histogram.setIcon(histIcon);
                histogram.setBackground(Color.white);

                plotGraph.add(histogram);



                //line graph

                BufferedImage imgline = null;
                try {
                    imgline = ImageIO.read(new File("line.png"));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Image dimgline = imgline.getScaledInstance(30,30, Image.SCALE_SMOOTH);
                ImageIcon lineIcon = new ImageIcon(dimgline);

                lineGraph.setIcon(lineIcon);
                lineGraph.setBackground(Color.white);

                plotGraph.add(lineGraph);

                //pie chart

                BufferedImage imgpie = null;
                try {
                    imgpie = ImageIO.read(new File("pie.png"));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Image dimgpie = imgpie.getScaledInstance(30,30, Image.SCALE_SMOOTH);
                ImageIcon pieIcon = new ImageIcon(dimgpie);

                pieChart.setIcon(pieIcon);
                pieChart.setBackground(Color.white);

                plotGraph.add(pieChart);


                //area graph

                BufferedImage imgarea = null;
                try {
                    imgarea = ImageIO.read(new File("donut.png"));
                } catch (IOException e) {
                    e.printStackTrace();
                }


                Image dimgarea = imgarea.getScaledInstance(30,30, Image.SCALE_SMOOTH);
                ImageIcon areaIcon = new ImageIcon(dimgarea);

                donutGraph.setIcon(areaIcon);
                donutGraph.setBackground(Color.white);

                plotGraph.add(donutGraph);


                //donut

                BufferedImage imgscatter= null;
                try {
                    imgscatter= ImageIO.read(new File("scatter.png"));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Image dimgscatter= imgscatter.getScaledInstance(30,30, Image.SCALE_SMOOTH);
                ImageIcon scatterIcon = new ImageIcon(dimgscatter);

                scatter.setIcon(scatterIcon);
                scatter.setBackground(Color.white);

                plotGraph.add(scatter);



                barGraph.addActionListener(this);
                scatter.addActionListener(this);
                donutGraph.addActionListener(this);
                pieChart.addActionListener(this);
                lineGraph.addActionListener(this);
                histogram.addActionListener(this);





        //spreadsheet panel contents
                spreadsheet.setBackground(Color.getHSBColor(0,0f,0.9f));

                //jtable
                String[] columns = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
                //CHANGES
                data =new String[][] {{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""},{"","","","","","","","","","","","","","","","","","","","","","","","","",""}};
                jTable = new JTable(data,columns);
                jTable.setPreferredScrollableViewportSize(new Dimension(750,200));
                jTable.setFillsViewportHeight(true);
                //System.out.println(data[0].length);
                //data is 60 rows of 26 cloumns each



                jTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

                JScrollPane jScrollPane = new JScrollPane(jTable);
                LineBorder lb = new LineBorder(Color.black, 0);
                jScrollPane.setBorder(lb);
                jScrollPane.setBackground(Color.getHSBColor(0,0f,0.9f));
                jScrollPane.setMaximumSize(spreadsheet.getMaximumSize());








                //CELL SELECTION CODE
                jTable.setCellSelectionEnabled(true);
                ListSelectionModel cellSelectionModel = jTable.getSelectionModel();
                cellSelectionModel.setValueIsAdjusting(true);
                ListSelectionModel columnSelectionModel = jTable.getColumnModel().getSelectionModel();

                cellSelectionModel.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
                columnSelectionModel.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);






                cellSelectionModel.addListSelectionListener(new ListSelectionListener() {
                      public void valueChanged(ListSelectionEvent e) {

                         jTextField.setText(jTable.getColumnName(jTable.getSelectedColumn()) + Integer.toString(jTable.getSelectedRow() + 1));
                       }

                });

                columnSelectionModel.addListSelectionListener(new ListSelectionListener() {
                    public void valueChanged(ListSelectionEvent e) {

                        jTextField.setText(jTable.getColumnName(jTable.getSelectedColumn()) + Integer.toString(jTable.getSelectedRow() + 1));
                    }

                });





               ListSelectionModel rowSSelectionModel = jTable.getSelectionModel();
                rowSSelectionModel.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

                rowSSelectionModel.addListSelectionListener(new ListSelectionListener() {
                    @Override
                    public void valueChanged(ListSelectionEvent e) {
                        int columns[] = jTable.getSelectedColumns();
                        int rows[] = jTable.getSelectedRows();
                        if ( !e.getValueIsAdjusting() && jTable.getSelectedRow()>-1 && jTable.getSelectedColumn()>-1) {
                            selectedCells=new String[columns.length][rows.length];
                            for (int i = 0; i < (columns.length); i++) {
                                for (int j = 0; j <(rows.length); j++) {
                                    selectedCells[i][j] = null;

                                }
                            }

                            for (int i = 0; i < columns.length; i++) {
                                for (int j = 0; j < rows.length; j++) {
                                    selectedCells[i][j] = (String) jTable.getValueAt(rows[j], columns[i]);
                                    selectedCellsPrint[i][j] = (String) jTable.getValueAt(rows[j], columns[i]);
                                }
                            }
                        }
                    }
                });


                ListSelectionModel columnSSelectionModel = jTable.getColumnModel().getSelectionModel();
                columnSSelectionModel.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

                columnSSelectionModel.addListSelectionListener(new ListSelectionListener() {
                    @Override
                    public void valueChanged(ListSelectionEvent e) {
                        int columns[] = jTable.getSelectedColumns();
                        int rows[] = jTable.getSelectedRows();

                        if ( !e.getValueIsAdjusting() && jTable.getSelectedRow()>-1 && jTable.getSelectedColumn()>-1) {
                             selectedCells=new String[columns.length][rows.length];

                            for (int i = 0; i < (columns.length); i++) {
                                for (int j = 0; j < (rows.length); j++) {
                                    selectedCells[i][j] = null;

                                }
                            }

                            for (int i = 0; i < columns.length; i++) {
                                for (int j = 0; j < rows.length; j++) {
                                    selectedCells[i][j] = (String) jTable.getValueAt(rows[j], columns[i]);

                                }
                            }
                            System.out.println(Arrays.deepToString(selectedCells));
                        }


                    }
                });


















                 //CREATE ROW HEADER

                    //MODEL FOR OUR ROW HEADER
                    ListModel lm = new AbstractListModel() {

                        //HEADER TEXT WE WANT DISPLAYED
                        String[] headers = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59","60"};

                        @Override
                        public int getSize() {
                            return headers.length;
                        }

                        @Override
                        public Object getElementAt(int index) {
                            return headers[index];
                        }
                    };


                    JList rowHeader = new JList(lm);
                    rowHeader.setFixedCellWidth(50);
                    rowHeader.setFixedCellHeight(jTable.getRowHeight());

                    //SET RENDERER
                    rowHeader.setCellRenderer(new RowRenderer(jTable));

                    //JSCROLLPANE
                    jScrollPane.setRowHeaderView(rowHeader);
                    getContentPane().add(jScrollPane);


                    spreadsheet.setLayout(new BorderLayout());
                    spreadsheet.add(jScrollPane, BorderLayout.CENTER);

        //add panels to jframe.
        f.add(plotGraph);
        f.add(spreadsheet);

        f.setVisible(true);

  //     Main.connect();//connect;
    }

    //changes
    private void loadFile(String text) {
        String[][] data = Main.getData(text);
        //clear the spreadsheet
        for(int i=0;i<26;i++){
            for(int j=0;j<60;j++){
                jTable.setValueAt("",j,i);
            }
        }

        int n;
        for(int i=0;i<6;i++){
            n=data[i].length;
            for(int j=0;j<n;j++){
                jTable.setValueAt(data[i][j],j,i);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {


        Object source = e.getSource();

        if(source == save){
            for (int i = 0; i < 60; i++) {
                for (int j = 0; j < 26; j++) {
                    selectedCellsPrint[j][i] = (String) jTable.getValueAt(i, j);
                }
            }
            JFileChooser fc = new JFileChooser(new File("c:\\"));

            fc.showSaveDialog(this);
            fc.setDialogTitle("Save Your File");

            File f = fc.getSelectedFile();

            try {
                FileWriter fw = new FileWriter(f);

                for(int i=0; i<60; ++i)
                {
                    for(int j=0; j<26; ++j)
                    {
                        String s;
                        if (selectedCellsPrint[j][i] == null){
                            s = "";
                        }
                        else{
                            s = selectedCellsPrint[j][i];
                        fw.write(s);
                        }
                        fw.write("\t\t");
                    }
                    fw.write("\n");
                }

                Main.WriteData(f.getName(),selectedCellsPrint[0],selectedCellsPrint[1],selectedCellsPrint[2],selectedCellsPrint[3],selectedCellsPrint[4],selectedCellsPrint[5]);
                fw.close();

            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        else if (source == exit){
            System.exit(0);
        }
        else if (source == open){
            int i=0;
            jTable.setValueAt("9",0,0);
            String[] fileNames = Main.getFileNames();

            while (fileNames[i] != null){
                //files[i] = new JMenuItem(fileNames[i]);
                System.out.println(fileNames[i]);
                open.add(fileNames[i]);
                i++;
            }

        }

        else if(source == files){
            //System.out.print;
        }


//int n=data.length;


        if(source == lineGraph || source == barGraph || source == donutGraph || source == histogram || source == pieChart || source==scatter) {

            JFrame alert = new JFrame("Alert");
            alert.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            alert.setSize(600, 200);
            alert.setLayout(new FlowLayout());
            alert.setLocationRelativeTo(null);

            JLabel errorMsg;


            int n = selectedCells[0].length;//row size
            int m = selectedCells.length;//col size
            //double[] data = new double[]{1.0D, 2.0D, 3.0D, 2.0D, 1.0D};
            double[][] plotData = new double[6][n];//row, coloum1
            for (int i = 0; i < 6; i++) {
                for (int k = 0; k < n; k++) {
                    plotData[i][k] = 0;
                }

            }
            boolean error = false;
            outerloop:
            for (int i = 0; i < m; i++) {
                for (int k = 0; k < n; k++) {

                    try {
                        plotData[i][k] = Double.parseDouble(selectedCells[i][k]);
                    } catch (NumberFormatException numberFormatException) {
                        //numberFormatException.printStackTrace();
                        //System.out.println(i);
                        if(i == 1 && k > 0){
                            errorMsg = new JLabel("Value Missing Or Incorrect Input");
                            errorMsg.setFont(new Font("Montserrat", Font.BOLD, 25));
                            alert.add(errorMsg);
                            alert.setVisible(true);
                            error = true;
                            break outerloop;
                        }
                        else {

                            //   return;
                            plotData[i][k] = 0;
                            error = false;
                        }
                    }
                }
            }


            // Main.WriteData("UNTITLED1",data[0],data[1],data[2],data[3],data[4],data[5]);
            //this           Main.WriteData("UNTITLED1",plotData[0],plotData[1],plotData[2],plotData[3],plotData[4],plotData[5]);


            // ERROR MESSAGE WHEN EMPTY CELL SELECTED AND MORE




            if( m <= 1){
                errorMsg = new JLabel("Please Select More Than One Column");
                errorMsg.setFont(new Font("Montserrat", Font.BOLD, 25));
                alert.add(errorMsg);
                alert.setVisible(true);
            }
            else if(n <= 1){
                errorMsg = new JLabel("Please Select More Than One Row");
                errorMsg.setFont(new Font("Montserrat", Font.BOLD, 25));
                alert.add(errorMsg);
                alert.setVisible(true);
            }
            else if (plotData[1][1] == 0) {

                errorMsg = new JLabel("Please Input Data In Selected Cells");
                errorMsg.setFont(new Font("Montserrat", Font.BOLD, 25));
                alert.add(errorMsg);
                alert.setVisible(true);
            }
            else if (selectedCells[0][0] == "") {
                errorMsg = new JLabel("Please Input Header In Top Left Cell");
                errorMsg.setFont(new Font("Montserrat", Font.BOLD, 25));
                alert.add(errorMsg);
                alert.setVisible(true);
            }
            else if (selectedCells[1][0] == "") {
                errorMsg = new JLabel("Please Input Values Title In Top Right Cell");
                errorMsg.setFont(new Font("Montserrat", Font.BOLD, 25));
                alert.add(errorMsg);
                alert.setVisible(true);
            }

            else {
                if (error == false){
                    JFrame myFrame = new JFrame();
                myFrame.setSize(615, 645);
                myFrame.setVisible(true);

                FlowLayout flowLayout = new FlowLayout();
                flowLayout.setAlignment(FlowLayout.CENTER);


                myFrame.setLayout(new BorderLayout(0, 0));

                if (source == barGraph) {

                    Graph graph = new Bar(plotData[1], 100, 100, selectedCells);
                    myFrame.add(graph, BorderLayout.CENTER);


                } else if (source == pieChart) {

                    Graph graph = new Pie(plotData[1], 100, 100, selectedCells);
                    myFrame.add(graph);

                } else if (source == lineGraph) {

                    Graph graph = new LineGraph(plotData[1], 100, 100, selectedCells);
                    myFrame.add(graph);

                } else if (source == histogram) {

                    Graph graph = new Histo(plotData[1], 100, 100, selectedCells);
                    myFrame.add(graph);

                } else if (source == donutGraph) {

                    Graph graph = new Doughnut(plotData[1], 100, 100, selectedCells);
                    myFrame.add(graph);
                } else if (source == scatter) {

                    Graph graph = new ScatterGraph(plotData[1], 100, 100, selectedCells);
                    myFrame.add(graph);

                } else
                    System.out.println("Working on the rest");
            }
            }

        }
    }










    public static void main(String[] args){

            new Menu();
    }

}



//RENDERER CLASS
class RowRenderer extends JLabel implements ListCellRenderer{

    public RowRenderer(JTable table)
    {
        JTableHeader header = table.getTableHeader();
        setOpaque(true);
        setBorder(UIManager.getBorder("TableHeader.cellBorder"));
        setHorizontalAlignment(CENTER);
        setForeground(header.getForeground());
        setBackground(header.getBackground());
        setFont(header.getFont());
    }


    @Override
    public Component getListCellRendererComponent(JList list, Object obj, int index, boolean selected, boolean focused) {
        setText((obj==null) ? "" : obj.toString());
        return this;
    }
}




class Graph extends JPanel {
    public static double[] values;
    public static String[] labels;
    public static String[] headers;
    private static int[] pos;
    private static Color[] COLORS;
    public int ds;

    public Graph(double[] data, int x, int y, String[][] labelz) {
        values = data;
        labels = labelz[0];
        headers = labelz[1];
        pos = new int[]{x, y};
        this.ds = data.length;
    }

    public double getValue(int i) {
        return i > -1 && i < values.length ? values[i] : -1.11D;
    }

    public Color getCOLOR(int i) {
        return i > -1 && i < COLORS.length ? COLORS[i] : null;
    }

    public int x() {
        return pos[0];
    }

    public int y() {
        return pos[1];
    }

    public static double dataMax() {
        double max = values[0];
        double[] var2 = values;
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            double x = var2[var4];
            max = Math.max(max, x);
        }

        return max;
    }

    static {
        Color c1=new Color(153, 0, 153);
        Color c2=new Color(230, 0, 92);
        Color c3=new Color(191, 64, 64);
        Color c4=new Color(204, 153, 0);
        Color c5=new Color(46, 184, 184);
        Color c6=new Color(255, 102, 0);
        Color c7=new Color(102, 102 , 51);
        Color c8=new Color(134, 45, 45);
        Color c9=new Color(0, 204, 153);
        COLORS = new Color[]{c5,c6,c7,c8,c9,Color.RED, Color.BLUE, Color.yellow, Color.GREEN, Color.cyan, Color.orange,c1, c2, c3,c4};
    }
}




class Bar extends Graph {
    private int[] graphSize;
    private double max = dataMax();

    public Bar(double[] data, int x, int y, String[][] labelz) {
        super(data, x, y, labelz);



    }


    @Override
    protected void paintComponent(Graphics g2) {
        super.paintComponent(g2);
        Graphics2D g = (Graphics2D)g2;
        setBackground(Color.white);//BACKGROUND COLOR CHANGE
        //int[] windowSize = new int[]{JFrame.getWindows()[0].getWidth(), JFrame.getWindows()[0].getHeight()};
        //CHANGE MADE HERE. THIS DEFINES THE SIZE OF THE WINDOW IN WHICH THE GRAPH WILL BE
        int[] windowSize = {615/2,645/2};
        this.graphSize = new int[]{windowSize[0], windowSize[1]};
        g.drawRect(this.x(), this.y(), this.graphSize[0], this.graphSize[1] + 10);

        int barWidth = Math.round((float)(this.graphSize[0] / this.ds));



        g.setFont(new Font("Montserrat",Font.PLAIN, 12));

        // For loop for the grid lines
        for(int i = 1; i < this.ds; ++i) {
            g.setColor(new Color(234,234,234));
            int barHeight = (int)Math.round(this.getValue(i) / this.max * (double)this.graphSize[1]);
            g.drawLine(this.x() - 5,this.y() + this.graphSize[1] - barHeight + 10,this.x() + this.ds * barWidth,this.y() + this.graphSize[1] - barHeight + 10);
            g.drawLine(this.x() - 5,this.y() + this.graphSize[1] - barHeight + 11,this.x() + this.ds * barWidth,this.y() + this.graphSize[1] - barHeight + 11);
        }


        for(int i = 1; i < this.ds; ++i) {
            int barHeight = (int)Math.round(this.getValue(i) / this.max * (double)this.graphSize[1]);
            //g.setColor(this.getCOLOR(i % this.ds));

            // X and Y- axis labelling
            g.setColor(new Color(100,100,100));


            AffineTransform orig = g.getTransform();
            g.rotate(Math.toRadians(-45),this.x() + (i-1) * barWidth, this.y() + 400);
            g.drawString(labels[i],this.x() + (i-1) * barWidth,this.y() + 400);
            g.setTransform(orig);



            g.drawString((String.valueOf(values[i])),this.x() - 35,this.y() + this.graphSize[1] - barHeight + 15);


           // g.drawLine(this.x() - 50,this.y() + this.graphSize[1] - barHeight + 10,this.x() + this.ds * barWidth,this.y() + this.graphSize[1] - barHeight + 10);
            g.setColor(this.getCOLOR(i % 15));

            g.fillRect(this.x() + (i-1) * barWidth, this.y() + this.graphSize[1] - barHeight + 10, barWidth, barHeight);

        }




        // Header
        g.setColor(Color.black);
        int barHeightt = (int)Math.round(this.getValue(0) / this.max * (double)this.graphSize[1]);
        g.setFont(new Font("Montserrat",Font.PLAIN,18));
        AffineTransform orig = g.getTransform();
        g.rotate(Math.toRadians(-90),(this.x() - this.graphSize[0]/6),this.y() + 200);
        g.drawString(headers[0],(this.x() - this.graphSize[0]/6), this.y() + 200);
        g.setTransform(orig);



        // axis Title
        g.setFont(new Font("Montserrat",Font.PLAIN,18));
        g.drawString(labels[0],(this.x() + this.graphSize[0])/2,this.y() + 450);

    }

}




class Histo extends Graph {
    private int[] graphSize;
    private double max = dataMax();

    public Histo(double[] data, int x, int y, String[][] labelz) {
        super(data, x, y,labelz);
    }

    protected void paintComponent(Graphics g2) {
        super.paintComponent(g2);
        Graphics2D g = (Graphics2D)g2;
        setBackground(Color.white);//BACKGROUND COLOR CHANGE
        //int[] windowSize = new int[]{JFrame.getWindows()[0].getWidth(), JFrame.getWindows()[0].getHeight()};
        //CHANGE MADE HERE. THIS DEFINES THE SIZE OF THE WINDOW IN WHICH THE GRAPH WILL BE
        int[] windowSize = {615,645};
        this.graphSize = new int[]{windowSize[0] / 2, windowSize[1] / 2};
        g.drawRect(this.x(), this.y(), this.graphSize[0], this.graphSize[1] + 10);
        int barWidth = Math.round((float)(this.graphSize[0] / this.ds));


        g.setFont(new Font("Montserrat",Font.PLAIN, 12));

        // For loop for the grid lines
        for(int i = 1; i < this.ds; ++i) {
            g.setColor(new Color(234,234,234));
            int barHeight = (int)Math.round(this.getValue(i) / this.max * (double)this.graphSize[1]);
            g.drawLine(this.x() - 5,this.y() + this.graphSize[1] - barHeight + 10,this.x() + this.ds * barWidth,this.y() + this.graphSize[1] - barHeight + 10);
            g.drawLine(this.x() - 5,this.y() + this.graphSize[1] - barHeight + 11,this.x() + this.ds * barWidth,this.y() + this.graphSize[1] - barHeight + 11);
        }


        for(int i = 1; i < this.ds; ++i) {
            int barHeight = (int)Math.round(this.getValue(i) / this.max * (double)this.graphSize[1]);

            // X and Y- axis labelling
            g.setColor(new Color(100,100,100));

            AffineTransform orig = g.getTransform();
            g.rotate(Math.toRadians(-45),this.x() + (i-1) * barWidth, this.y() + 400);
            g.drawString(labels[i],this.x() + (i-1) * barWidth + 10,this.y() + 400);
            g.setTransform(orig);



            g.drawString((String.valueOf(values[i])),this.x() - 35,this.y() + this.graphSize[1] - barHeight + 15);


            g.setColor(this.getCOLOR(i % 15));
            g.fillRect(this.x() + (i-1) * barWidth + 10, this.y() + this.graphSize[1] - barHeight + 10, barWidth - 10, barHeight);

        }


        // Header
        g.setColor(Color.black);
        int barHeightt = (int)Math.round(this.getValue(0) / this.max * (double)this.graphSize[1]);
        g.setFont(new Font("Montserrat",Font.PLAIN,18));
        AffineTransform orig = g.getTransform();
        g.rotate(Math.toRadians(-90),(this.x() - this.graphSize[0]/6),this.y() + 200);
        g.drawString(headers[0],(this.x() - this.graphSize[0]/6), this.y() + 200);
        g.setTransform(orig);



        // axis Title
        g.setFont(new Font("Montserrat",Font.PLAIN,18));
        g.drawString(labels[0],(this.x() + this.graphSize[0])/2,this.y() + 450);
    }
}




class ScatterGraph extends Graph {
    private int[] graphSize;
    private double max = dataMax();

    public ScatterGraph(double[] data, int x, int y, String[][] labelz) {
        super(data, x, y, labelz);
    }

    protected void paintComponent(Graphics g2) {
        super.paintComponent(g2);
        Graphics2D g = (Graphics2D)g2;

        setBackground(Color.white);//BACKGROUND COLOR CHANGE
        //int[] windowSize = new int[]{JFrame.getWindows()[0].getWidth(), JFrame.getWindows()[0].getHeight()};
        //CHANGE MADE HERE. THIS DEFINES THE SIZE OF THE WINDOW IN WHICH THE GRAPH WILL BE
        int[] windowSize = {615,645};
        this.graphSize = new int[]{windowSize[0] / 2, windowSize[1] / 2};
        int[] xPoints = new int[this.ds];
        int[] yPoints = new int[this.ds];
        //g.clearRect(this.x(), this.y(), this.graphSize[0], this.graphSize[1] + 10);
        int barWidth = Math.round((float)(this.graphSize[0] / this.ds));


        // For loop for the grid lines
        for(int i = 1; i < this.ds; ++i) {
            g.setColor(new Color(234,234,234));
            int barHeight = (int)Math.round(this.getValue(i) / this.max * (double)this.graphSize[1]);
            g.drawLine(this.x() - 5,this.y() + this.graphSize[1] - barHeight + 10,this.x() + this.ds * barWidth,this.y() + this.graphSize[1] - barHeight + 10);
            g.drawLine(this.x() - 5,this.y() + this.graphSize[1] - barHeight + 11,this.x() + this.ds * barWidth,this.y() + this.graphSize[1] - barHeight + 11);
        }


        for(int i = 1; i < this.ds; ++i) {
            int barHeight = (int)Math.round(this.getValue(i) / this.max * (double)this.graphSize[1]);



            g.setColor(this.getCOLOR(i % 15));
            xPoints[i-1] = this.x() + i * barWidth;
            yPoints[i-1] = this.y() + this.graphSize[1] - barHeight + 10;
            g.fillOval(xPoints[i-1] - 5, yPoints[i-1] - 5, 10, 10);


            // X and Y- axis labelling
            g.setColor(new Color(100,100,100));

            AffineTransform orig = g.getTransform();
            g.rotate(Math.toRadians(-45),this.x() + (i-1) * barWidth, this.y() + 400);
            g.drawString(labels[i],xPoints[i-1],this.y() + 400);
            g.setTransform(orig);


            g.drawString((String.valueOf(values[i])),this.x() - 35,this.y() + this.graphSize[1] - barHeight + 15);

        }


        // Header
        g.setColor(Color.black);
        int barHeightt = (int)Math.round(this.getValue(0) / this.max * (double)this.graphSize[1]);
        g.setFont(new Font("Montserrat",Font.PLAIN,18));
        AffineTransform orig = g.getTransform();
        g.rotate(Math.toRadians(-90),(this.x() - this.graphSize[0]/6),this.y() + 200);
        g.drawString(headers[0],(this.x() - this.graphSize[0]/6), this.y() + 200);
        g.setTransform(orig);



        // axis Title
        g.setFont(new Font("Montserrat",Font.PLAIN,18));
        g.drawString(labels[0],(this.x() + this.graphSize[0])/2,this.y() + 450);
    }
}





class LineGraph extends Graph {
    private int[] graphSize;
    private double max = dataMax();

    public LineGraph(double[] data, int x, int y, String[][] labelz) {
        super(data, x, y, labelz);
    }

    protected void paintComponent(Graphics g2) {
        super.paintComponent(g2);
        Graphics2D g = (Graphics2D)g2;
        setBackground(Color.white);//BACKGROUND COLOR CHANGE
        //int[] windowSize = new int[]{JFrame.getWindows()[0].getWidth(), JFrame.getWindows()[0].getHeight()};
        //CHANGE MADE HERE. THIS DEFINES THE SIZE OF THE WINDOW IN WHICH THE GRAPH WILL BE
        int[] windowSize = {615,645};
        this.graphSize = new int[]{windowSize[0] / 2, windowSize[1] / 2};
        int[] xPoints = new int[this.ds];
        int[] yPoints = new int[this.ds];
        //g.clearRect(this.x(), this.y(), this.graphSize[0], this.graphSize[1] + 10);
        int barWidth = Math.round((float)(this.graphSize[0] / this.ds));


        // For loop for the grid lines
        for(int i = 1; i < this.ds; ++i) {
            g.setColor(new Color(234,234,234));
            int barHeight = (int)Math.round(this.getValue(i) / this.max * (double)this.graphSize[1]);
            g.drawLine(this.x() - 5,this.y() + this.graphSize[1] - barHeight + 10,this.x() + this.ds * barWidth,this.y() + this.graphSize[1] - barHeight + 10);
            g.drawLine(this.x() - 5,this.y() + this.graphSize[1] - barHeight + 11,this.x() + this.ds * barWidth,this.y() + this.graphSize[1] - barHeight + 11);
        }


        for(int i = 1; i < this.ds; ++i) {
            int barHeight = (int)Math.round(this.getValue(i) / this.max * (double)this.graphSize[1]);



            g.setColor(this.getCOLOR(i % 15));
            xPoints[i-1] = this.x() + i * barWidth;
            yPoints[i-1] = this.y() + this.graphSize[1] - barHeight + 10;
            g.fillOval(xPoints[i-1] - 5, yPoints[i-1] - 5, 10, 10);


            // X and Y- axis labelling
            g.setColor(new Color(100,100,100));

            AffineTransform orig = g.getTransform();
            g.rotate(Math.toRadians(-45),this.x() + (i-1) * barWidth, this.y() + 400);
            g.drawString(labels[i],xPoints[i-1],this.y() + 400);
            g.setTransform(orig);


            g.drawString((String.valueOf(values[i])),this.x() - 35,this.y() + this.graphSize[1] - barHeight + 15);

        }

        g.drawPolyline(xPoints, yPoints, this.ds-1);

        // Header
        g.setColor(Color.black);
        int barHeightt = (int)Math.round(this.getValue(0) / this.max * (double)this.graphSize[1]);
        g.setFont(new Font("Montserrat",Font.PLAIN,18));
        AffineTransform orig = g.getTransform();
        g.rotate(Math.toRadians(-90),(this.x() - this.graphSize[0]/6),this.y() + 200);
        g.drawString(headers[0],(this.x() - this.graphSize[0]/6), this.y() + 200);
        g.setTransform(orig);



        // axis Title
        g.setFont(new Font("Montserrat",Font.PLAIN,18));
        g.drawString(labels[0],(this.x() + this.graphSize[0])/2,this.y() + 450);
    }
}




class Pie extends Graph {
    private int[] graphSize;
    private double sum = 0.0D;
    private double max = dataMax();

    public Pie(double[] data, int x, int y, String[][] labelz) {
        super(data, x, y, labelz);
        double[] var4 = data;
        int var5 = data.length;

        for(int var6 = 0; var6 < var5; ++var6) {
            double i = var4[var6];
            this.sum += i;
        }

    }


    protected void paintComponent(Graphics g2) {
        super.paintComponent(g2);
        Graphics2D g = (Graphics2D)g2;
        setBackground(Color.white);//BACKGROUND COLOR CHANGE
        //int[] windowSize = new int[]{JFrame.getWindows()[0].getWidth(), JFrame.getWindows()[0].getHeight()};
        //CHANGE MADE HERE. THIS DEFINES THE SIZE OF THE WINDOW IN WHICH THE GRAPH WILL BE
        int[] windowSize = {615,615};
        this.graphSize = new int[]{windowSize[0] / 2, windowSize[1] / 2};
        int[] angles = new int[this.ds];


        g.setColor(Color.black);
        g.drawString(headers[0], this.x() - 30, this.y() + 370);
        g.drawString(labels[0], this.x() - 30, this.y() + 350);

        int startpt;
        for(startpt = 0; startpt < this.ds; ++startpt) {
            angles[startpt] = (int)Math.round(this.getValue(startpt) / this.sum * 360.0D);
        }

        startpt = 0;

        for(int i = 0; i < this.ds; ++i) {
            g.setColor(this.getCOLOR(i % 15));

            g.fillArc(this.x(), this.y(), windowSize[0] / 2, windowSize[0] / 2, startpt, angles[i]);


            startpt += angles[i];


            // X and Y- axis labelling
            if(i < this.ds-1 ) {
                g.setColor(this.getCOLOR(i+1 % 15));

                AffineTransform orig = g.getTransform();
                g.rotate(Math.toRadians(-45),this.x() + (i+1) * (Math.round((float) (this.graphSize[0] / this.ds))), this.y() + 350);
                g.drawString(labels[i + 1], this.x() + (i+1) * (Math.round((float) (this.graphSize[0] / this.ds))), this.y() + 350);
                g.setTransform(orig);



                g.rotate(Math.toRadians(-45),this.x() + (i+1) * (Math.round((float) (this.graphSize[0] / this.ds))), this.y() + 370);
                g.setColor(new Color(100, 100, 100));
                g.drawString((String.valueOf(values[i + 1])), this.x() + (i+1) * (Math.round((float) (this.graphSize[0] / this.ds))), this.y() + 370);
                g.setTransform(orig);
            }
        }
       // g.setColor(Color.white);
        //g.fillOval(151,150,205,205);
        /*g.fillOval(this.x()+windowSize[0]/8,this.y()+windowSize[0]/8,windowSize[0]/4,windowSize[0]/4);*/

    }
}

class Doughnut extends Graph {
    private int[] graphSize;
    private double sum = 0.0D;
    private double max = dataMax();

    public Doughnut(double[] data, int x, int y, String[][] labelz) {
        super(data, x, y, labelz);
        double[] var4 = data;
        int var5 = data.length;

        for(int var6 = 0; var6 < var5; ++var6) {
            double i = var4[var6];
            this.sum += i;
        }

    }



    protected void paintComponent(Graphics g2) {
        super.paintComponent(g2);
        Graphics2D g = (Graphics2D)g2;
        setBackground(Color.white);//BACKGROUND COLOR CHANGE
        //int[] windowSize = new int[]{JFrame.getWindows()[0].getWidth(), JFrame.getWindows()[0].getHeight()};
        //CHANGE MADE HERE. THIS DEFINES THE SIZE OF THE WINDOW IN WHICH THE GRAPH WILL BE
        int[] windowSize = {615,645};
        this.graphSize = new int[]{windowSize[0] / 2, windowSize[1] / 2};
        int[] angles = new int[this.ds];


        int startpt;
        for(startpt = 0; startpt < this.ds; ++startpt) {
            angles[startpt] = (int)Math.round(this.getValue(startpt) / this.sum * 360.0D);
        }

        startpt = 0;

        g.setColor(Color.black);
        g.drawString(headers[0], this.x() - 30, this.y() + 370);
        g.drawString(labels[0], this.x() - 30, this.y() + 350);

        for(int i = 0; i < this.ds; ++i) {
            //g.setColor(this.getCOLOR(i % this.ds));
            g.setColor(this.getCOLOR(i % 15));
            g.fillArc(this.x(), this.y(), windowSize[0] / 2, windowSize[0] / 2, startpt, angles[i]);
            startpt += angles[i];

            if(i < this.ds-1 ) {
                g.setColor(this.getCOLOR(i+1 % 15));

                AffineTransform orig = g.getTransform();
                g.rotate(Math.toRadians(-45),this.x() + (i+1) * (Math.round((float) (this.graphSize[0] / this.ds))), this.y() + 350);
                g.drawString(labels[i + 1], this.x() + (i+1) * (Math.round((float) (this.graphSize[0] / this.ds))), this.y() + 350);
                g.setTransform(orig);



                g.rotate(Math.toRadians(-45),this.x() + (i+1) * (Math.round((float) (this.graphSize[0] / this.ds))), this.y() + 370);
                g.setColor(new Color(100, 100, 100));
                g.drawString((String.valueOf(values[i + 1])), this.x() + (i+1) * (Math.round((float) (this.graphSize[0] / this.ds))), this.y() + 370);
                g.setTransform(orig);
            }

        }
        g.setColor(Color.white);
        g.fillOval(151,150,205,205);
        /*g.fillOval(this.x()+windowSize[0]/8,this.y()+windowSize[0]/8,windowSize[0]/4,windowSize[0]/4);*/



    }
}
