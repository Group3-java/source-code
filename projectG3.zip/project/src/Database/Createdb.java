package Database;

import java.sql.*;

public class Createdb {
    public static void createDbase(){
        Connection c=null;
        Statement stmt=null;
        String sql;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            c=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","getpass");
            System.out.println("Opened successfully ");

            stmt=c.createStatement();//statement object of the database

            //sql="DROP TABLE IF EXISTS DATA";
             sql="CREATE TABLE DATA "+
                   "(ID  INT AUTO_INCREMENT PRIMARY KEY,"+
                    "DOC_NAME TEXT  NOT NULL,"+
                    "COL1DATA TEXT ,"+
                    "COL2DATA TEXT ,"+
                    "COL3DATA TEXT ,"+
                    "COL4DATA TEXT ,"+
                    "COL5DATA TEXT ,"+
                    "COL6DATA TEXT )";
            stmt.executeUpdate(sql);

            System.out.println("Table created successfully ");
            stmt.close();
            c.close();
        }
        catch (Exception e) {
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            System.exit(0);
        }

    }

}
