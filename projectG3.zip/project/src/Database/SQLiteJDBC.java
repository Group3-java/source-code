package Database;

import java.sql.*;


public class SQLiteJDBC {
    public static void main(String[] args ){

        Connection c=null;
        Statement stmt=null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            c=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","getpass");
            System.out.println("Opened successfully ");

           // stmt=c.createStatement();
           // String sql="CRAETE TABLE USER" +
             //       "KEY  AUTOINCREMENT  NOT NILL,"+
             //       "ONE                 NOT NUL "

        }catch (Exception e) {
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            System.exit(0);
        }

    }
}
