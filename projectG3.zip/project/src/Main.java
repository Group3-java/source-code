//package Database;
import Database.Createdb;

import java.util.Scanner;
import  java.sql.*;
import  static java.lang.Integer.parseInt;

public class Main {

    private static Connection c;
    private static Statement stmt;
    private static ResultSet result;
    private static int id;
    private static String namee;
    private static String col1;
    private static String col2;
    public static void main(String[] args ){
        connect();

        //Createdb.createDbase();
        String name;
        System.out.println("Enter the name");
        Scanner choose = new Scanner(System.in);
        name = choose.nextLine();

        String[] col_1=new String[10];
        System.out.println("Enter data for column 1");
        for(int i=0; i<10; i++){
            col_1[i]=choose.nextLine();
        }

        String[] col_2=new String[10];
        System.out.println("Enter data for column 2");
        for(int i=0; i<10; i++){
            col_2[i]=choose.nextLine();
        }

       /* String[] col_3=new String[10];
        System.out.println("Enter data for column 1");
        for(int i=0; i<10; i++){
            col_3[i]=choose.nextLine();
        }
        */

       /* System.out.println(name);
        for(int i=0; i<10; i++){
            System.out.println(col_1[i]+" "+col_2[i]+" "+ col_3[i]);*/

        String hold1="";
        for(int i=0; i<10; i++){
            hold1+=col_1[i];
            if(i<9){
                hold1+= "," ;
            }
        }

        String hold2="";
        for(int i=0; i<10; i++){
            hold2+=col_2[i];
            if(i<9){
                hold2+= "," ;
            }
        }

        //System.out.println(hold1);
        //System.out.println(hold2);

        String sql="INSERT INTO DATA(DOC_NAME,COL1DATA,COL2DATA)"+
                "VALUES('"+name+"','"+hold1+"','"+hold2+"');";

        String[] column1=new String[10];
        String[] column2=new String[10];
        int[]rcol1=new int[10];
        int[]rcol2=new int[10];
        try {
            stmt.executeUpdate(sql);

            //stmt.executeUpdate("DELETE FROM DATA");

            result=stmt.executeQuery("SELECT * FROM DATA");// QUERY THE DATABASE


            while (result.next()){
                id=result.getInt("ID");
                System.out.println(id );

                namee=result.getString("DOC_NAME");
                System.out.println(namee);

                col1=result.getString("COL1DATA");
                System.out.println(col1 );

                col2=result.getString("COL2DATA");
                System.out.println(col2 );

            }
            column1=col1.split(",");
            column2=col2.split(",");


            for(int i=0; i<10; i++) {
                parseInt(column1[i]);
                parseInt(column2[i]);
                System.out.println(column1[i] + "   " + column2[i]);

            }
            result.close();
            stmt.close();
            c.close();

        }
        catch (Exception e){
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
        }
    }


    public static void  connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            c=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","getpass");
            System.out.println("Opened successfully ");

            stmt=c.createStatement();

        } catch (Exception e) {
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            System.exit(0);
        }
    }
    public static void  WriteData(String DOC_NAME, String[] C1, String[] C2,String[] C3,String[] C4,String[] C5,String[] C6 ) {

        String[] hold={"","","","","",""};


        //System.out.println(hold1);
        //System.out.println(hold2);

        String sql ;//="INSERT INTO DATA(DOC_NAME,COL1DATA,COL2DATA)"+
        //"VALUES('"+name+"','"+hold1+"','"+hold2+"');";

        int n=C1.length;

        for(int i=0; i<n;i++)
        {
            hold[0]+= C1[i];
            hold[1]+= C2[i];
            hold[2]+= C3[i];
            hold[3]+= C4[i];
            hold[4]+= C5[i];
            hold[5]+= C6[i];

            if(i<(n-1)) {
                hold[0]+=",";
                hold[1]+=",";
                hold[2]+=",";
                hold[3]+=",";
                hold[4]+=",";
                hold[5]+=",";
            }
        }
        sql="INSERT INTO DATA(DOC_NAME,COL1DATA,COL2DATA,COL3DATA,COL4DATA,COL5DATA,COL6DATA)"+
                "VALUES('"+DOC_NAME+"','"+hold[0]+"','"+hold[1]+"','"+hold[2]+"','"+hold[3]+"','"+hold[4]+"','"+hold[5]+"');";

        try {
            stmt.executeUpdate(sql);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static String[] getFileNames() {
        String[] fileNames = {null,null,null,null,null,null,null,null,null,null};
        int i=0;
        try{
            String sql = "select doc_name from data order by id desc limit 10";
            result = stmt.executeQuery(sql);


            while (result.next()){
                fileNames[i] = result.getString("doc_name");
                //System.out.println(fileNames[i]);
                i++;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return fileNames;
    }

    public static String[][] getData(String text) {
        String[][] data = new String[6][];
        String col;
        String sql = "select * from data where doc_name = '"+text+"' order by id desc";
        try{
            result = stmt.executeQuery(sql);
            if (result.next()){
                for(int i=0;i<6;i++){
                    col = result.getString(i+3);
                    data[i] = col.split(",");
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return data;
    }
}
